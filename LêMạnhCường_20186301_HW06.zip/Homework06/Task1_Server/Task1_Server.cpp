// WSAEventSelectServer.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#define PORT 6000
#define BUFF_SIZE 2048
#define SERVER_ADDR "127.0.0.1"
#define WM_SOCKET 2500
#define MAX_CLIENT 64
#define MAX_USER 100
#define MAX_ACTION 8
#define MAX_ACCOUNT 3



//  STRUCT: Session
//
//  PURPOSE: client - Save client connect to sever
//           ipAddressPort - save string : ClientIP:ClientPort$
//           loginStatus - save login status 
struct Session
{
	SOCKET client;
	char ipAddressPort[100];
	bool loginStatus;
};

Session session[MAX_CLIENT];






//--------------------Data I/O-------------------------


//  FUNCTION: deleteSession()
//
//  PURPOSE: delete login session of client
void deleteSession(SOCKET client) {
	for (int i = 0; i < MAX_CLIENT; i++) {
		if (session[i].client == client)
			session[i] = { 0,NULL,false };
		break;
	}
}

//  FUNCTION: checkLogin()
//
//  PURPOSE: check  - Is client login?
//          return : 1 logged in 
//                   0 not
int checkLogin(SOCKET client) {
	for (int i = 0; i < MAX_CLIENT; i++)
		if (client == session[i].client && session[i].loginStatus) return 1;
	return 0;
}


//  FUNCTION: getBuffer()
//
//  PURPOSE: create buffer " ClientIP:ClientPort "
//
//  COMMENT:  the function generates the string ClientIP:ClientPort and then assigns it to buff
void getBuffer(char *buff,sockaddr_in address) {
	char buff2[10] = "";
	char ipAddress[20] = "";
	inet_ntop(AF_INET, &(address.sin_addr), ipAddress, INET_ADDRSTRLEN);
	int port = address.sin_port;
	_itoa(port, buff2, 10);
	strcpy(buff, ipAddress);
	strcat(buff, ":");
	strcat(buff, buff2);
}

//  FUNCTION:  addSession(SOCKET client)
//
//  PURPOSE: add client to session list
//
//  COMMENT: add client to session list when new client has first request
void addSession(SOCKET client, sockaddr_in address) {
	for (int i = 0; i < MAX_CLIENT; i++) {
		if (session[i].client == 0) {
			session[i].client = client;
			getBuffer(session[i].ipAddressPort,address);
			break;
		}
	}
}

//  FUNCTION: searchBuffer()
//
//  PURPOSE: buffer " ClientIP:ClientPort " of client in struct Session
//
//  COMMENT: this function returns string " ClientIP:ClientPort " with client
char *searchBuffer(SOCKET client) {
	for (int i = 0; i < MAX_CLIENT; i++) {
		if (session[i].client == client) {
			return session[i].ipAddressPort;
		}
	}
	return NULL;
}




//  FUNCTION: getTime()
//
//  PURPOSE: get string : current time 
//
//  COMMENT:
const std::string getTime() {
	time_t     now = time(0);
	struct tm  tstruct;
	char       buf[80];
	tstruct = *localtime(&now);

	strftime(buf, sizeof(buf), "%d-%m-%Y %X", &tstruct);

	return buf;
}

//  FUNCTION: writeLog()
//
//  PURPOSE: write log action to file log_20186301.txt
void writeLog(char *buff, SOCKET client) {
	FILE *fp;
	char buffer[500] = "";
	strcpy(buffer, searchBuffer(client));
	strcat(buffer, " [");
	strcat(buffer, getTime().c_str());
	strcat(buffer, "]");
	strcat(buffer, buff);
	strcat(buffer, "\n");

	fp = fopen("log_20186301.txt", "a");
	fprintf(fp, buffer);
	fclose(fp);
};




//  FUNCTION: checkAccount()
//
//  PURPOSE: check user request
//      return : 1  login with lock account
//               2  login with correct account
//               3  login with wrong account 
//               4  logout
//               5  post
//               6  error message
//               7  server error
int checkRequest(char *buff, char *user) {
	FILE *fp;
	char buffer[MAX_USER];
	char action[MAX_ACTION];
	char username[MAX_USER];
	int IsExist = 0, status;
	int index;

	for (int i = 0; i < strlen(buff); i++) {
		if (buff[i] == ' ' || buff[i] == '\n') {
			action[i] = 0;
			index = i + 1;
			break;
		}
		else action[i] = buff[i];
	}

	if (strcmp(action, "LOGIN") == 0) {
		for (int i = index; i < (signed)strlen(buff); i++) {
			if (buff[i] == '\n') {
				username[i - index] = 0;
				index = i + 1;
				break;
			}
			else username[i - index] = buff[i];
		}

		fp = fopen("account.txt", "r");
		while (!feof(fp)) {
			fscanf(fp, "%s", buffer);
			if (strcmp(buffer, username) != 0) {
				fgets(buffer, MAX_USER, (FILE*)fp);
			}
			else {
				IsExist = 1;
				fscanf(fp, "%s", buffer);
				switch (buffer[0]) {
				case '1': status = 1; break;
				case '0': status = 0; break;
				}
				break;
			}
		}
		fclose(fp);
		strcpy(user, username);
		if (IsExist == 1) {
			if (status == 1) {
				strcpy(buff, "Account Locked!!!!");
				return 1;
			}
			else {
				strcpy(buff, "Login Success!!!");
				return 2;
			}
		}
		else {
			strcpy(buff, "Account Failed!!!!!!");
			return 3;
		}
	}
	else if (strcmp(action, "LOGOUT") == 0) {
		strcpy(buff, "Loggout Success!!!");
		return 4;
	}
	else if (strcmp(action, "POST") == 0) {
		return 5;
	}
	else {
		return 6;
	}
	return 7;
}



//--------------------Bussiness-----------------------


//  FUNCTION: recvMessage()
//
//  PURPOSE: recvice message from client
int recvMessage(SOCKET socket, char *buff, int lengthRecvBuff, int flag) {
	int ret;
	ret = recv(socket, buff, lengthRecvBuff, flag);
	if (ret <= 0)
		printf("\nRecvice message error!!!!");
	else
		buff[ret] = 0;
	return ret;
}
//  FUNCTION: sendMessage()
//
//  PURPOSE: send message to client :socket
void sendMessage(SOCKET socket, char *buff, int lengthSendBuff, int flag) {
	int ret;
	ret = send(socket, buff, lengthSendBuff, flag);
	if (ret <= 0)
		printf("\nSend message error!!!!");
}


//  FUNCTION: updateLogin()
//
//  PURPOSE: setting client logged in
void updateLogin(SOCKET client, bool status) {
	for (int i = 0; i < MAX_CLIENT; i++) {
		if (session[i].client == client) {
			session[i].loginStatus = status;
			break;
		}
	}
}


//  FUNCTION: handleData()
//
//  PURPOSE: handle data when the client recvices data from client
void handleData(char *buff, SOCKET client) {
	char user[MAX_USER];
	int ret, ret1;
	ret = checkRequest(buff, user);
	ret1 = checkLogin(client);
	char buffer[BUFF_SIZE] = "";

	if (ret1 == 1) {  // logged in
		if (ret == 1 || ret == 2 || ret == 3) { //Login false
			strcat(buffer, "$ LOGIN ");
			strcat(user, "$ -ERR");
			strcat(buffer, user);
		}
		else if (ret == 4) {//logout success
			strcat(buffer, "$ LOGOUT $ +OK");
		}
		else if (ret == 5) {//post success
			buff[strlen(buff) - 1] = 0;
			strcat(buffer, "$ ");
			strcat(buff, "$ +OK");
			strcat(buffer, buff);
		}
	}
	else if (ret1 == 0) { //not login
		if (ret == 1 || ret == 3) {//Login false
			strcat(buffer, "$ LOGIN ");
			strcat(user, "$ -ERR");
			strcat(buffer, user);
		}
		else if (ret == 2) {//login success
			strcat(buffer, "$ LOGIN ");
			strcat(user, "$ +OK");
			strcat(buffer, user);
		}
		else if (ret == 4) {//logout err
			strcat(buffer, "$ LOGOUT $ -ERR");
		}
		else if (ret == 5) { //post err
			buff[strlen(buff) - 1] = 0;
			strcat(buffer, "$ ");
			strcat(buff, "$ -ERR");
			strcat(buffer, buff);
		}
	}
	writeLog(buffer, client);



	if (ret1 == 1) {
		if (ret == 1 || ret == 2 || ret == 3) {
			strcpy(buff, "You are logged in!!");
		}
		else if (ret == 4) {
			updateLogin(client, false);
		}
		else if (ret == 5) {
			strcpy(buff, "Post successful >>>");
		}
	}
	else if (ret1 == 0) {
		if (ret == 5 || ret == 4) {
			strcpy(buff, "You need login!!!");
		}
		else if (ret == 2) {
			updateLogin(client,true);
		}
	}

	if (ret == 6) {
		strcat(buffer, "$ WARNING!!!");
		strcpy(buff, "Don't try to destroy the server :)");
	}
	else if (ret == 7) {
		strcpy(buff, "Server Failed , Try again!!!");
	}

	sendMessage(client, buff, strlen(buff), 0);
	

}










int main(int argc, char* argv[])
{
	DWORD		nEvents = 0;
	DWORD		index;
	SOCKET		socks[WSA_MAXIMUM_WAIT_EVENTS];
	WSAEVENT	events[WSA_MAXIMUM_WAIT_EVENTS];
	WSANETWORKEVENTS sockEvent;

	//Step 1: Initiate WinSock
	WSADATA wsaData;
	WORD wVersion = MAKEWORD(2, 2);
	if (WSAStartup(wVersion, &wsaData)) {
		printf("Winsock 2.2 is not supported\n");
		return 0;
	}

	//Step 2: Construct LISTEN socket	
	SOCKET listenSock;
	listenSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	//Step 3: Bind address to socket
	sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(atoi(argv[1]));
	inet_pton(AF_INET, SERVER_ADDR, &serverAddr.sin_addr);

	socks[0] = listenSock;
	events[0] = WSACreateEvent(); //create new events
	nEvents++;

	// Associate event types FD_ACCEPT and FD_CLOSE
	// with the listening socket and newEvent   
	WSAEventSelect(socks[0], events[0], FD_ACCEPT | FD_CLOSE);


	if (bind(listenSock, (sockaddr *)&serverAddr, sizeof(serverAddr)))
	{
		printf("Error %d: Cannot associate a local address with server socket.", WSAGetLastError());
		return 0;
	}

	//Step 4: Listen request from client
	if (listen(listenSock, 10)) {
		printf("Error %d: Cannot place server socket in state LISTEN.", WSAGetLastError());
		return 0;
	}

	printf("Server started!\n");

	char  recvBuff[BUFF_SIZE];
	SOCKET connSock;
	sockaddr_in clientAddr;
	int clientAddrLen = sizeof(clientAddr);
	int ret, i;
	FILE *fp;

	for (int k = 0; k < MAX_CLIENT; k++) {
		session[k] = { 0,NULL,false };
	}

	char file[] = "tungbt 0\nadmin 0\nlevn 0\nductq 1";

	fp = fopen("account.txt", "r");
	if (fp == NULL) {
		fp = fopen("account.txt", "a");
		fprintf(fp, file);
	}
	fclose(fp);

	for (i = 1; i < WSA_MAXIMUM_WAIT_EVENTS; i++) {
		socks[i] = 0;
	}
	while (1) {
		//wait for network events on all socket
		index = WSAWaitForMultipleEvents(nEvents, events, FALSE, WSA_INFINITE, FALSE);
		if (index == WSA_WAIT_FAILED) {
			printf("Error %d: WSAWaitForMultipleEvents() failed\n", WSAGetLastError());
			break;
		}

		index = index - WSA_WAIT_EVENT_0;
		WSAEnumNetworkEvents(socks[index], events[index], &sockEvent);

		if (sockEvent.lNetworkEvents & FD_ACCEPT) {
			if (sockEvent.iErrorCode[FD_ACCEPT_BIT] != 0) {
				printf("FD_ACCEPT failed with error %d\n", sockEvent.iErrorCode[FD_READ_BIT]);
				break;
			}

			if ((connSock = accept(socks[index], (sockaddr *)&clientAddr, &clientAddrLen)) == SOCKET_ERROR) {
				printf("Error %d: Cannot permit incoming connection.\n", WSAGetLastError());
				break;
			}

			//Add new socket into socks array
			int i;
			if (nEvents == WSA_MAXIMUM_WAIT_EVENTS) {
				char buff[100] = "";
				strcat(buff, "$ CONNECT $ -ERR");
				writeLog(buff, connSock);
				printf("\nToo many clients.");
				closesocket(connSock);
			}
			else
				for (i = 1; i < WSA_MAXIMUM_WAIT_EVENTS; i++)
					if (socks[i] == 0) {
						socks[i] = connSock;
						events[i] = WSACreateEvent();
						addSession(socks[i], clientAddr);
						char buff[100] = "";
						strcat(buff, "$ CONNECT $ +OK");
						writeLog(buff, socks[i]);
						WSAEventSelect(socks[i], events[i], FD_READ | FD_CLOSE);
						nEvents++;
						break;
					}

			//reset event
			WSAResetEvent(events[index]);
		}

		if (sockEvent.lNetworkEvents & FD_READ) {
			//Receive message from client
			if (sockEvent.iErrorCode[FD_READ_BIT] != 0) {
				printf("FD_READ failed with error %d\n", sockEvent.iErrorCode[FD_READ_BIT]);
				break;
			}

			ret = recvMessage(socks[index], recvBuff, BUFF_SIZE, 0);

			//Release socket and event if an error occurs
			if (ret <= 0) {
				char buffer[100] = "";
				strcat(buffer, "$ QUIT $ +OK");
				writeLog(buffer, socks[index]);
				deleteSession(socks[index]);

				closesocket(socks[index]);
				socks[index] = 0;
				WSACloseEvent(events[index]);
				nEvents--;
			}
			else {
				handleData(recvBuff, socks[index]);
				WSAResetEvent(events[index]);
			}
		}

		if (sockEvent.lNetworkEvents & FD_CLOSE) {
			if (sockEvent.iErrorCode[FD_CLOSE_BIT] != 0) {

				printf("FD_CLOSE failed with error %d\n", sockEvent.iErrorCode[FD_CLOSE_BIT]);
				char buffer[100] = "";
				strcat(buffer, "$ QUIT $ +OK");
				writeLog(buffer, socks[index]);
				deleteSession(socks[index]);

				closesocket(socks[index]);
				socks[index] = 0;
				WSACloseEvent(events[index]);
				nEvents--;
				continue;
			}
			//Release socket and event
			char buffer[100] = "";
			strcat(buffer, "$ QUIT $ +OK");
			writeLog(buffer, socks[index]);
			deleteSession(socks[index]);
			closesocket(socks[index]);
			socks[index] = 0;
			WSACloseEvent(events[index]);
			nEvents--;
		}
	}
	return 0;
}
