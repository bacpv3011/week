// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#define _CRT_SECURE_NO_WARNINGS
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdio.h>
#include <conio.h>
#include <iostream>
#include <string>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <process.h>
#include <tchar.h>
#pragma comment (lib,"ws2_32.lib")




// TODO: reference additional headers your program requires here
