
// WSAEventSelectServer.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#define BUFF_SIZE 20500
#define MAX_LENGTH 9
#define MAX_INDEX 10000

//     0: encode
//     1: decode
struct SESSION 
{
	SOCKET client;
	char link[20];
	char linkFin[24];
	int isEncode; 
	char key;
};
SESSION session[WSA_MAXIMUM_WAIT_EVENTS];


//  FUNCTION: convertLength(char * len, int length, int nByte)
//
//  PURPOSE: convert length to n bits
//
//  COMMENT: This function represents the integer Length to nByte
void convertLength(char * len, int length, int nByte) {
	int bit;
	int b;
	for (int i = 0; i < nByte; i++) {
		b = 1;
		for (int j = 0; j < 6; j++) {
			bit = length % 2;
			if (bit == 1) {
				b += pow(2, j);
			}
			length /= 2;
			if (length == 0) break;
		}
		len[nByte - i - 1] = b;
	}
	len[nByte] = 0;
}


//  FUNCTION: matchMessage(char *message, char *buff,int len)
//
//  PURPOSE: concatenate data to send
// 
//  COMMENT: this function concatenates the buff string to the message string. 
//           The message string contains the request code and the buff string length
void matchMessage(char *message, char *buff, int len) {
	char length[4];
	convertLength(length, len, 3);
	message[1] = length[0];
	message[2] = length[1];
	message[3] = length[2];
	message[4] = 0;
	strcat(message, buff);
}
//  FUNCTION: writeToFile(char *file, char *buff, int length)
//
//  PURPOSE: write data to file
//
//  COMMENT: The function writes the buff string containing
//           the data of the file received from the client into the result file
void writeToFile(char *file,char *buff,int length) {
	FILE *fp;
	int len = length / 2;
	unsigned char ch;
	fp = fopen(file,"ab");
	for (int i = 0; i < len; i++) {
		ch = (unsigned char)((buff[2*i] - 1) * 16 + buff[2*i+1] - 1);
		fputc(ch, fp);
	}
	
	fclose(fp);
}
void getLength(char *length, int len) {
	char buff[8] = "";
	_itoa(len, buff, 10);
	for (int i = 0; i < 8 - (signed)strlen(buff); i++) {
		length[i] = '0';
	}
	strcat(length, buff);
}
//  FUNCTION:   checkSession(SOCKET client)
//
//  PURPOSE:  check  client is in session or not
int checkSession(SOCKET client) {
	for (int i = 0; i < WSA_MAXIMUM_WAIT_EVENTS; i++) {
		if (client == session[i].client) return i;
	}
	return -1;
}
//  FUNCTION:  updateSession(int index, char head, int key)
//
//  PURPOSE: session update
//
//  COMMENT: update session when user change request
void updateSession(int index, char head, int key) {
	if (head == '0') {
		session[index].isEncode = 0;
	}
	else
	{
		session[index].isEncode = 1;
	}
	session[index].key = char(key);
}

//  FUNCTION:  addSession(SOCKET client)
//
//  PURPOSE: add client to session list
//
//  COMMENT: add client to session list when new client has first request
void addSession(SOCKET client) {
	char buff[15];
	for (int i = 0; i < WSA_MAXIMUM_WAIT_EVENTS; i++) {
		if (session[i].client == 0) {
			session[i].client=client;
			_itoa(client, buff, 10);
			strcat(buff, ".bin");
			strcat(session[i].link, buff);
			strcat(session[i].linkFin, session[i].link);
			strcat(session[i].linkFin, ".fin");
			break;
		}
	}
}
//  FUNCTION: deleteAllFile(SOCKET client)
//
//  PURPOSE: delete all files generated from encryption/decryption process
//
//  COMMENT: delete all files by client index in session
void deleteAllFile(SOCKET client) {
	int index = checkSession(client);
	remove(session[index].link);
	remove(session[index].linkFin);
}

//  FUNCTION: deleteSession(SOCKET client)
//
//  PURPOSE: delete current session
//
void deleteSession(SOCKET client){
	int index = checkSession(client);
	session[index] = { 0,NULL,NULL,2,NULL };
}
//  FUNCTION: sendMessage()
//
//  PURPOSE: send message to client
//
//  COMMENT: The function sends the buff string to the client
int sendMessage(SOCKET connSock, char *buff, int length) {
	int ret;
	ret = send(connSock, buff, length, 0);
	if (ret == SOCKET_ERROR) {
		printf("Error : %d\n", WSAGetLastError());
	}
	return ret;
}

//  FUNCTION: sendData(SOCKET client, char *link)
//
//  PURPOSE: send file data to client
// 
//  COMMENT: This function takes binary data from result 
//           file and sends it to the server
//           File with path  *link
void sendData(SOCKET client, char *link) {
	FILE *fp;
	int ret;
	char message[BUFF_SIZE + 10] = "2";
	char buff[BUFF_SIZE];
	char notice[10];
	char finMessage[] = { 50,1,1,1 };
	int index = 0;
	unsigned char ch;

	fp = fopen(link, "rb");

	while (1) {
		ch = fgetc(fp);
		if (feof(fp)) {
			if (index > 0) {
				buff[index * 2] = 0;
				matchMessage(message, buff, index);
				ret = sendMessage(client, message, index * 2 + 4);
				while (ret <= 0) {
					ret = sendMessage(client, message, index * 2 + 4);
				}
				ret = sendMessage(client, finMessage, 4);
				while (ret <= 0) {
					ret = sendMessage(client, message, index * 2 + 4);
				}
			}
			break;
		}
		else {
			if (index == MAX_INDEX) {
				buff[index * 2] = 0;
				matchMessage(message, buff, index);
				ret = sendMessage(client, message, index * 2 + 4);
				while (ret <= 0) {
					ret = sendMessage(client, message, index * 2 + 4);
				}
				index = 0;
			}
			buff[index * 2] = (char)(ch / 16 + 1);
			buff[index * 2 + 1] = (char)(ch % 16 + 1);
			index++;
		}
	}

	fclose(fp);
	
}
//  FUNCTION: EndecodeFile(int index) 
//
//  PURPOSE: encode decode file
//
//  COMMENT: the function to encrypt and decrypt files
//           according to the index of the client in the session
void EndecodeFile(int index) {
	char file2[20]= "";
	int isEncode = session[index].isEncode;
	char key = session[index].key;
	strcpy(file2, session[index].link);
	strcat(file2, ".fin");
	FILE *ofp, *nfp;
	unsigned char ch;

	if ((ofp = fopen(session[index].link, "rb")) == NULL) {
		fclose(ofp);
		return ;
	}

	if ((nfp = fopen(file2, "wb")) == NULL) {
		fclose(nfp);
		return;
	}
	if (isEncode == 0) {
		while (1) {
			ch = fgetc(ofp);
			if (!feof(ofp)) {
				fputc((ch + 64) % 256, nfp);
			}
			else
				break;
		}

	}
	else if(isEncode == 1) {
		while (1) {
			ch = fgetc(ofp);
			if (!feof(ofp)) {
				fputc((ch - key) % 256, nfp);
			}
			else
				break;
		}

	}

	fclose(nfp);
	fclose(ofp);

	sendData(session[index].client, file2);
}

//  FUNCTION: recvRequest(SOCKET client)
//
//  PURPOSE: receive requests from users
//
//  COMMENT: The function receives and processes requests from the client
int recvRequest(SOCKET client) {
	
	char head[5];
	char tmp[11];
	char buff[BUFF_SIZE];
	unsigned int key;
	int ret, nLeft,index;

	ret = recv(client, head, 4, 0);

	if (ret == SOCKET_ERROR) {
		printf("Error : 1:  %d", WSAGetLastError());
		return 0;
	}
	head[ret] = 0;

	nLeft = ((int)head[1] - 1) * (int)pow(2, 12) + ((int)head[2] - 1) * (int)pow(2, 6) + (int)(head[3]) - 1;
	
	int ret1 = checkSession(client);
	if (head[0] == '0' || head[0] == '1') {
		ret = recv(client, tmp, nLeft, 0);
		if (ret == SOCKET_ERROR) {
			printf("Error : 2: %d", WSAGetLastError());
			return -1;
		}
		tmp[ret] = 0;
		key = atoi(tmp);
		key %= 256;

		updateSession(ret1, head[0], key);
		return 1;
	}
	else if (head[0] == '2') {
		if (ret1 >= 0) {
			if (nLeft == 0) {
				EndecodeFile(ret1);
				deleteAllFile(client);
				return 1;
			}
			else {
				nLeft *= 2;
				while (nLeft>0) {
					index = (nLeft > BUFF_SIZE - 2) ? BUFF_SIZE - 2 : nLeft;
					ret = recv(client, buff, index, 0);
					if (ret == SOCKET_ERROR) {
						printf("Error : 3: %d", WSAGetLastError());
						return -1;
					}
					else {
						writeToFile(session[ret1].link, buff,index);
					}
					nLeft -= ret;
				}
				send(client,"4",1,0);
				return 1;
			}
		}
	}
	else  
		return -1;
}

int main(int argc, char* argv[])
{
	DWORD		nEvents = 0;
	DWORD		index = 0;
	SOCKET		socks[WSA_MAXIMUM_WAIT_EVENTS];
	WSAEVENT	events[WSA_MAXIMUM_WAIT_EVENTS];
	WSANETWORKEVENTS sockEvent;

	//Step 1: Initiate WinSock
	WSADATA wsaData;
	WORD wVersion = MAKEWORD(2, 2);
	if (WSAStartup(wVersion, &wsaData)) {
		printf("Winsock 2.2 is not supported\n");
		return 0;
	}

	//Step 2: Construct LISTEN socket	
	SOCKET listenSock;
	listenSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	//Step 3: Bind address to socket
	sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(atoi(argv[1]));
	inet_pton(AF_INET, "127.0.0.1", &serverAddr.sin_addr);

	socks[0] = listenSock;
	events[0] = WSACreateEvent(); //create new events
	nEvents++;

	// Associate event types FD_ACCEPT and FD_CLOSE
	// with the listening socket and newEvent   
	WSAEventSelect(socks[0], events[0], FD_ACCEPT | FD_CLOSE);


	if (bind(listenSock, (sockaddr *)&serverAddr, sizeof(serverAddr)))
	{
		printf("Error %d: Cannot associate a local address with server socket.", WSAGetLastError());
		return 0;
	}

	//Step 4: Listen request from client
	if (listen(listenSock, 10)) {
		printf("Error %d: Cannot place server socket in state LISTEN.", WSAGetLastError());
		return 0;
	}

	printf("Server started!\n");

	SOCKET connSock;
	sockaddr_in clientAddr;
	int clientAddrLen = sizeof(clientAddr);
	int ret, i;

	for (i = 0; i < WSA_MAXIMUM_WAIT_EVENTS; i++) {
		session[i] = { 0,NULL,NULL,2,NULL };
	}
	for (i = 1; i < WSA_MAXIMUM_WAIT_EVENTS; i++) {
		socks[i] = 0;
		session[i] = { 0,NULL,2,NULL};
	}
	while (1) {
		//wait for network events on all socket
		index = WSAWaitForMultipleEvents(nEvents, events, FALSE, WSA_INFINITE, FALSE);
		if (index == WSA_WAIT_FAILED) {
			printf("Error %d: WSAWaitForMultipleEvents() failed\n", WSAGetLastError());
			break;
		}

		index = index - WSA_WAIT_EVENT_0;
		
		WSAEnumNetworkEvents(socks[index], events[index], &sockEvent);

		if (sockEvent.lNetworkEvents & FD_ACCEPT) {
			if (sockEvent.iErrorCode[FD_ACCEPT_BIT] != 0) {
				printf("FD_ACCEPT failed with error %d\n", sockEvent.iErrorCode[FD_READ_BIT]);
				break;
			}

			if ((connSock = accept(socks[index], (sockaddr *)&clientAddr, &clientAddrLen)) == SOCKET_ERROR) {
				printf("Error %d: Cannot permit incoming connection.\n", WSAGetLastError());
				break;
			}

			//Add new socket into socks array
			int i;
			if (nEvents == WSA_MAXIMUM_WAIT_EVENTS) {
				printf("\nToo many clients.");
				closesocket(connSock);
			}
			else
				for (i = 1; i < WSA_MAXIMUM_WAIT_EVENTS; i++)
					if (socks[i] == 0) {
						socks[i] = connSock;
						addSession(socks[i]);
						events[i] = WSACreateEvent();
						WSAEventSelect(socks[i], events[i], FD_READ | FD_CLOSE);
						nEvents++;
						break;
					}

			//reset event
			WSAResetEvent(events[index]);
		}

		if (sockEvent.lNetworkEvents & FD_READ) {
			//Receive message from client
			if (sockEvent.iErrorCode[FD_READ_BIT] != 0) {
				printf("FD_READ failed with error %d\n", sockEvent.iErrorCode[FD_READ_BIT]);
				break;
			}
			ret = recvRequest(socks[index]);
			//Release socket and event if an error occurs
			if (ret< 0) {

				deleteSession(socks[index]);
				deleteAllFile(socks[index]);

				closesocket(socks[index]);
				socks[index] = 0;
				WSACloseEvent(events[index]);
				nEvents--;
			}
			else {
				WSAResetEvent(events[index]);
			}
		}

		if (sockEvent.lNetworkEvents & FD_CLOSE) {
			deleteSession(socks[index]);
			deleteAllFile(socks[index]);
			closesocket(socks[index]);
			socks[index] = 0;
			WSACloseEvent(events[index]);
			nEvents--;
			if (sockEvent.iErrorCode[FD_CLOSE_BIT] != 0) {
				printf("FD_CLOSE failed with error %d\n", sockEvent.iErrorCode[FD_CLOSE_BIT]);
				continue;
			}
			
			//Release socket and event

		}
	}
	return 0;
}