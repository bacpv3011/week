// Client.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#define BUFF_SIZE 20480
#define MAX_INDEX 10000
#define MAX_CLIENT 2048
#define MAX_LINK 200




//-----------------Data I/O----------------------

//  FUNCTION: writeToFile(char *file, char *buff, int length)
//
//  PURPOSE: write data to file
//
//  COMMENT: The function writes the buff string containing
//           the data of the file received from the server into the result file
void writeToFile(char *file, char *buff, int length) {
	FILE *fp;
	int len = length / 2;
	unsigned char ch;
	fp = fopen(file, "ab");
	for (int i = 0; i < len; i++) {
		ch = (unsigned char)((buff[2 * i] - 1) * 16 + buff[2 * i + 1] - 1);
		fputc(ch, fp);

	}

	fclose(fp);
}

//  FUNCTION: sendMessage()
//
//  PURPOSE: send message from client to server
//
//  COMMENT: The function sends the buff string to the server

int sendMessage(SOCKET connSock, char *buff, int length) {
	int ret;
	ret = send(connSock, buff, length, 0);
	if (ret == SOCKET_ERROR) {
		printf("Error : %d", WSAGetLastError());
	}
	return ret;
}

//  FUNCTION: recvMessage()
//
//  PURPOSE: recvice message from server
//
//  COMMENT: the function receives the string from 
//           the server and stores it in the variable recvBuff
int recvMessage(SOCKET socket, char *recvBuff) {
	int ret;
	ret = recv(socket, recvBuff, BUFF_SIZE, 0);
	if (ret == SOCKET_ERROR) {
		printf("Error! Cannot receive message.");
	}
	else if (strlen(recvBuff) > 0) {
		recvBuff[ret] = 0;
	}

	return ret;
}

//  FUNCTION: convertLength(char * len, int length, int nByte)
//
//  PURPOSE: convert length to n bits
//
//  COMMENT: This function represents the integer Length to nByte
void convertLength(char * len, int length, int nByte) {
	int bit;
	int b;
	for (int i = 0; i < nByte; i++) {
		b = 1;
		for (int j = 0; j < 6; j++) {
			bit = length % 2;
			if (bit == 1) {
				b += pow(2, j);

			}
			length /= 2;
			if (length == 0) break;
		}
		len[nByte - i - 1] = b;

	}
	len[nByte] = 0;
}
//  FUNCTION: matchMessage(char *message, char *buff,int len)
//
//  PURPOSE: concatenate data to send
// 
//  COMMENT: this function concatenates the buff string to the message string. 
//           The message string contains the request code and the buff string length
void matchMessage(char *message, char *buff, int len) {
	char length[4];
	convertLength(length, len, 3);
	message[1] = length[0];
	message[2] = length[1];
	message[3] = length[2];
	message[4] = 0;
	strcat(message, buff);
}


//  FUNCTION: checkKey(char *key)
//
//  PURPOSE:  check user input
//
//  COMMENT: Check the key value the user entered is numeric or not
bool checkKey(char *key) {
	for (int i = 0; i < strlen(key); i++) {
		if ('9' <= key[i] ||key[i] <= '0') {
			return false;
		}
	}
	return true;
}

//  FUNCTION: sendData(SOCKET client, char *link)
//
//  PURPOSE: send file data to server
// 
//  COMMENT: This function takes binary data from the 
//           user input file and sends it to the server
//           File with path  *link
void sendData(SOCKET client, char *link) {
	FILE *fp;
	int ret;
	char message[BUFF_SIZE + 4] = "2";
	char buff[BUFF_SIZE];
	char finMessage[] = { 50,1,1,1 };
	char notice[10];
	int index = 0;
	unsigned char ch;

	fp = fopen(link, "rb");

	while (1) {
		ch = fgetc(fp);
		if (feof(fp)) {
			if (index > 0) {
				buff[index * 2] = 0;
				matchMessage(message, buff, index);
				sendMessage(client, message, index * 2 + 4);
				ret = recv(client, notice, 1, 0);
				if (ret <= 0 || notice[0] == '3') {
					return;
				}
			}
			break;
		}
		else {
			if (index == MAX_INDEX) {
				buff[index * 2] = 0;
				matchMessage(message, buff, index);
				sendMessage(client, message, index * 2 + 4);
				ret = recv(client, notice, 1, 0);
				if (ret <= 0 || notice[0] == '3') {
					return;
				}
				index = 0;
			}
			buff[index * 2] = (char)(ch / 16 + 1);
			buff[index * 2 + 1] = (char)(ch % 16 + 1);
			index++;
		}
	}

	fclose(fp);
	sendMessage(client, finMessage, 4);
	printf("Sent data ^^^ Wait for Server...\n");

}

//  FUNCTION: recvData(SOCKET client, char *link,char *link2)
//
//  PURPOSE: recvice file data from server
// 
//  COMMENT: This function receives the result file data from the server
//           then save the result to file2
void recvData(SOCKET client, char *link, char *link2) {
	char head[5];
	char buff[BUFF_SIZE];
	int ret = 0, nLeft;
	int index;
	while (1) {
		ret = recv(client, head, 4, 0);

		if (ret == SOCKET_ERROR) {
			printf("Error : %d", WSAGetLastError());
			return;
		}
		head[ret] = 0;

		nLeft = ((int)head[1] - 1) * (int)pow(2, 12) + ((int)head[2] - 1) * (int)pow(2, 6) + (int)(head[3]) - 1;

		if (head[0] == '2') {
			if (nLeft == 0) {
				return;
			}
			else {

				nLeft *= 2;
				while (nLeft>0) {
					index = (nLeft > BUFF_SIZE - 1) ? BUFF_SIZE - 1 : nLeft;
					ret = recv(client, buff, index, 0);
					if (ret == SOCKET_ERROR) {
						printf("Error : %d", WSAGetLastError());
						return;
					}
					else {
						writeToFile(link2, buff, index);

					}
					nLeft -= ret;
				}
			}
		}
		else if (head[0] == '3') {
			return;
		}
	}
	printf("\nFinished!!! press any key to continue");
}


//-----------------Bussiness----------------------


//  FUNCTION: checkLink(char *link)
//
//  PURPOSE: Check the link the user entered is correct or not
// 
//  COMMENT: This function opens the file that the user enters. 
//           If it opens, it returns true
bool checkLink(char *link) {
	FILE *fp;

	fp = fopen(link, "rb");
	if (fp == NULL) return false;

	fclose(fp);
	return true;
}



//  FUNCTION: encode()
//
//  PURPOSE: handle user encode request
// 
void encode(SOCKET socket) {
	char messageEncode[BUFF_SIZE +3] = "0";
	char key[11] ="";
	unsigned int k;
	char link[MAX_LINK] ="";
	char link2[MAX_LINK+5]="";
	FILE *fp;

	printf("Input link to file:"); gets_s(link);

	if (strlen(link) == 0) return;

	while (!checkLink(link)) {
		printf("Link failed!!!\n");
		printf("Input again: "); gets_s(link);
		if (strlen(link) == 0) return;
	}
	printf("Input key:"); gets_s(key);
	while (!checkKey(key)) {
		printf("Input key again:"); gets_s(key);
	}
	printf("Your key :%s \n", key);
	matchMessage(messageEncode, key, strlen(key));

	sendMessage(socket, messageEncode, strlen(key) + 4);

	
	
	sendData(socket,link);

	strcpy(link2, link);
	strcat(link2, ".enc");
	recvData(socket, link,link2);
}

//  FUNCTION: decode()
//
//  PURPOSE: handle user decode request
// 
      
void decode(SOCKET socket) {
	char messageDecode[BUFF_SIZE + 3] = "1";
	char key[11] = "";
	char link[MAX_LINK] = "";
	char link2[MAX_LINK] = "";
	FILE *fp;

	
	printf("Input link to file:"); gets_s(link);

	if (strlen(link) == 0) return;

	while (!checkLink(link)) {
		printf("Link failed!!!\n");
		printf("Input again: "); gets_s(link);
		if (strlen(link) == 0) return;
	}
	printf("Input key:"); gets_s(key);
	while (!checkKey(key)) {
		printf("Input key again:"); gets_s(key);
	}
	printf("Your key :%s \n", key);
	matchMessage(messageDecode, key, strlen(key));

	sendMessage(socket, messageDecode, strlen(key) + 4);

	sendData(socket, link);
	strcpy(link2, link);
	strcat(link2, ".dec");
	recvData(socket, link,link2);
}

//-------------------GUI-------------------------

//  FUNCTION: login()
//
//  PURPOSE: create GUI for user
// 
//  COMMENT: This function creates the interface for the user and 
//           links with other functions to handle the request for the user
void multiChoice(SOCKET socket) {
	char c;
	while (1) {
		printf("\tEncode-Decode Program\n");
		printf("1.Encode\n");
		printf("2.Decode\n");
		printf("3.Exit\n");
		printf("Input your choice :");
		c = _getch();
		printf("%c\n", c);
		switch (c) {
		case '1': encode(socket); break;
		case '2': decode(socket); break;
		case '3':  exit(0);
		default:printf("Error !! Input again !! OK?"); break;
		}
		_getch();
		system("cls");
	}
}

int main(int argc, char **argv)
{
	//initialize winsock
	WSADATA wsaData;
	DWORD iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) printf("Start Error!!");
	//construct socket
	SOCKET clientSock;
	clientSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	//specify serverAddr
	sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(atoi(argv[2]));
	serverAddr.sin_addr.s_addr = inet_addr(argv[1]);
														//connect server
	if (connect(clientSock, (sockaddr *)&serverAddr, sizeof(serverAddr))) {
		printf("Can't connect to server!!");
		_getch();
	}
	printf("Connected to server!\n");
	multiChoice(clientSock);

	//Terminate Winsock
	WSACleanup();


	return 0;
}
