// Client.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


#define BUFF_SIZE 2048
#define MAX_CLIENT 2048


//-----------------Bussiness----------------------


//  FUNCTION: sendMessage()
//
//  PURPOSE: send message from client to server
//
//  COMMENT: The function sends the buff string to the server

void sendMessage(SOCKET connSock, char *buff) {
	int ret;
	ret = send(connSock, buff, strlen(buff), 0);
	if (ret <= 0)
		printf("\nSend message error!!!!");
}

//  FUNCTION: recvMessage()
//
//  PURPOSE: recvice message from server
//
//  COMMENT: the function receives the string from 
//           the server and stores it in the variable recvBuff
void recvMessage(SOCKET socket) {
	int ret;
	char recvBuff[BUFF_SIZE];
	ret = recv(socket, recvBuff, BUFF_SIZE, 0);
	if (ret == SOCKET_ERROR) {
		printf("Error! Cannot receive message.");
	}
	else if (strlen(recvBuff) > 0) {
		recvBuff[ret] = 0;
		printf("Receive from server:%s", recvBuff);
	}
}
//  FUNCTION: login()
//
//  PURPOSE: handle when the user selects the login function 
void login(SOCKET socket) {
	char messageLogin[BUFF_SIZE];
	strcpy(messageLogin, "LOGIN ");
	char user[100];
	printf("User name:"); gets_s(user, 100);
	strcat(messageLogin, user);
	strcat(messageLogin, "\n");
	sendMessage(socket, messageLogin);
	recvMessage(socket);
}

//  FUNCTION: logout()
//
//  PURPOSE: handle when the user selects the logout function 
void logout(SOCKET socket) {
	char mesLogout[] = "LOGOUT\n";
	sendMessage(socket, mesLogout);
	recvMessage(socket);
}

//  FUNCTION: post()
//
//  PURPOSE: handle when the user selects the post function 
void post(SOCKET socket) {
	char messagePost[BUFF_SIZE + 5] = "POST ";
	char content[BUFF_SIZE];
	printf("Content:"); gets_s(content, BUFF_SIZE);
	strcat(messagePost, content);
	strcat(messagePost, "\n");
	sendMessage(socket, messagePost);
	recvMessage(socket);
}


//-------------------GUI-------------------------

//  FUNCTION: login()
//
//  PURPOSE: create GUI for user
void multiChoice(SOCKET socket) {
	int choice = 0;
	while (1) {
		printf("\tLogin-Post\n");
		printf("1.Login\n");
		printf("2.Logout\n");
		printf("3.Post\n");
		printf("4.Exit\n");
		printf("Input your choice :");
		char c = _getch();
		printf("%c\n", c);
		switch (c) {
		case '1': login(socket); break;
		case '2': logout(socket); break;
		case '3': post(socket); break;
		case '4': exit(0);
		default:printf("Error !! Input again :"); break;
		}
		_getch();
		system("cls");
	}
}

int main(int argc, char **argv)
{
	//initialize winsock
	WSADATA wsaData;
	DWORD iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) printf("Start Error!!");
	//construct socket
	SOCKET clientSock;
	clientSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	//specify serverAddr
	sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(atoi(argv[2]));
	serverAddr.sin_addr.s_addr = inet_addr(argv[1]);
														//connect server
	if (connect(clientSock, (sockaddr *)&serverAddr, sizeof(serverAddr))) {
		printf("Can't connect to server!!");
		_getch();
	}
	printf("Connected to server!\n");
	multiChoice(clientSock);

	//Terminate Winsock
	WSACleanup();


	return 0;
}
